from __future__ import annotations

import json
import os
import time
from typing import Any, Dict, List, Optional, Sequence

from openai import OpenAI


def _call_with_backoff(fn, max_retries: int = 5, base_delay: float = 1.0):
    """
    Very small retry helper for hackathon demos.
    Retries on any Exception to keep things simple.
    """
    last_err = None
    for i in range(max_retries):
        try:
            return fn()
        except Exception as e:  # noqa
            last_err = e
            if i == max_retries - 1:
                raise
            time.sleep(base_delay * (2 ** i))
    raise last_err  # type: ignore[misc]


def _truncate(text: str, max_chars: int = 12000) -> str:
    text = (text or "").strip()
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 200] + "\n\n...(truncated)...\n"


class OpenAIService:
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gpt-5.2",
        embedding_model: str = "text-embedding-3-small",
    ):
        api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY가 설정되지 않았습니다. (환경변수 또는 UI에서 입력)")
        self.client = OpenAI(api_key=api_key)
        self.model = model
        self.embedding_model = embedding_model

    def summarize(
        self,
        *,
        url: str,
        title: str,
        content: str,
        metrics: Optional[Dict[str, Any]] = None,
        language: str = "ko",
    ) -> Dict[str, Any]:
        """
        Returns a dict that matches the schema below (Structured Outputs).
        Uses Responses API + text.format(json_schema).
        """
        content = _truncate(content, max_chars=14000)
        metrics = metrics or {}

        schema = {
            "type": "object",
            "properties": {
                "title": {"type": "string", "minLength": 1},
                "one_liner": {"type": "string"},
                "summary": {"type": "string"},
                "key_points": {"type": "array", "items": {"type": "string"}, "minItems": 3, "maxItems": 8},
                "tags": {"type": "array", "items": {"type": "string"}, "minItems": 3, "maxItems": 10},
                "audience": {"type": "array", "items": {"type": "string"}, "minItems": 1, "maxItems": 6},
                "recommended_angles": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 2,
                    "maxItems": 6,
                },
                "risk_notes": {"type": "string"},
            },
            "required": [
                "title",
                "one_liner",
                "summary",
                "key_points",
                "tags",
                "audience",
                "recommended_angles",
                "risk_notes",
            ],
            "additionalProperties": False,
        }

        system = (
            "너는 프로덕트/콘텐츠 전략가이자 에디터다. "
            "사용자가 높은 체류시간/방문을 보인 콘텐츠를 빠르게 이해할 수 있게 요약하고, "
            "다음 콘텐츠로 확장할 아이디어(Angles)를 제안한다. "
            "반드시 한국어로 작성하라."
        )

        user = f"""
[메타데이터]
- URL: {url}
- 추정 제목: {title or "(unknown)"}
- 메트릭: {json.dumps(metrics, ensure_ascii=False)}

[원문 텍스트]
{content}
""".strip()

        def _do():
            return self.client.responses.create(
                model=self.model,
                input=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                # Structured Outputs for Responses API
                text={
                    "format": {
                        "type": "json_schema",
                        "name": "staypick_summary",
                        "schema": schema,
                        "strict": True,
                    }
                },
                store=False,
            )

        resp = _call_with_backoff(_do)
        raw = resp.output_text
        data = json.loads(raw)
        data["url"] = url
        data["metrics"] = metrics
        return data

    def embed_texts(self, texts: Sequence[str]) -> List[List[float]]:
        def _do():
            return self.client.embeddings.create(
                model=self.embedding_model,
                input=list(texts),
            )

        resp = _call_with_backoff(_do)
        return [d.embedding for d in resp.data]

    def web_trends(self, query: str) -> str:
        """
        Optional: uses built-in web_search tool via Responses API.
        """
        query = (query or "").strip()
        if not query:
            return ""

        prompt = (
            "다음 키워드/주제에 대해 '최근 트렌드' 관점에서 참고할 만한 핵심 이슈 5개를 뽑고, "
            "각 이슈를 2~3문장으로 요약해줘. 한국어로 작성해줘.\n\n"
            f"키워드: {query}"
        )

        def _do():
            return self.client.responses.create(
                model=self.model,
                tools=[{"type": "web_search"}],
                input=prompt,
                store=False,
            )

        resp = _call_with_backoff(_do)
        return resp.output_text

    def generate_content(
        self,
        *,
        summaries: List[Dict[str, Any]],
        persona: str,
        output_format: str,
        additional_context: str = "",
        external_trends: str = "",
        language: str = "ko",
    ) -> str:
        """
        Produces a new piece of content in Markdown.
        """
        if not summaries:
            raise ValueError("summaries가 비어있습니다")

        # Keep prompt size in check
        compact_items = []
        for s in summaries:
            compact_items.append(
                {
                    "title": s.get("title"),
                    "url": s.get("url"),
                    "one_liner": s.get("one_liner"),
                    "key_points": s.get("key_points"),
                    "tags": s.get("tags"),
                    "recommended_angles": s.get("recommended_angles"),
                    "metrics": s.get("metrics"),
                }
            )

        system = (
            "너는 '리서치 → 재가공'에 특화된 콘텐츠 에디터다. "
            "아래 인사이트 묶음을 기반으로 완전히 새로운(복사/붙여넣기 금지) 콘텐츠를 만든다. "
            "원문 표현을 그대로 길게 재사용하지 말고, 핵심 의미만 재구성해라. "
            "출력은 마크다운(Markdown)로 작성하라. "
            "한국어로 작성하라."
        )

        user = f"""
[목표 페르소나]
{persona}

[원하는 산출물 포맷]
{output_format}

[내부 '체류시간 상위' 콘텐츠 인사이트]
{json.dumps(compact_items, ensure_ascii=False)}

[외부 트렌드 참고(있을 경우)]
{external_trends or "(없음)"}

[추가 컨텍스트/브랜드 톤]
{additional_context or "(없음)"}

요구사항:
1) {persona}가 관심 가질 만한 '훅(첫 문단/첫 문장)'을 강하게.
2) 읽기 쉬운 섹션 구조(H2/H3).
3) 실행 가능한 체크리스트/다음 액션 포함.
4) 마지막에 "Sources" 섹션을 만들고, 위 URL을 불릿으로 나열(간단 코멘트 1줄씩).
""".strip()

        def _do():
            return self.client.responses.create(
                model=self.model,
                input=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                store=False,
            )

        resp = _call_with_backoff(_do)
        return resp.output_text
