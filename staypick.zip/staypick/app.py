from __future__ import annotations

import os
import json
from datetime import datetime
from typing import Any, Dict, List

import pandas as pd
import streamlit as st
from dotenv import load_dotenv

from modules.metrics import load_metrics_csv, compute_engagement_score, top_by_score
from modules.fetch import fetch_and_extract
from modules.ai import OpenAIService
from modules.cluster import cluster_summaries


load_dotenv()

st.set_page_config(page_title="StayPick", layout="wide")

st.title("StayPick — 체류시간 기반 트렌드 콘텐츠 자동 생성기")
st.caption("Analytics(CSV) → 체류시간 상위 콘텐츠 추출 → 요약/인사이트 → 타겟 맞춤 새 콘텐츠 생성")


# ---------------------------
# Sidebar
# ---------------------------
with st.sidebar:
    st.header("설정")

    api_key = st.text_input(
        "OPENAI_API_KEY",
        type="password",
        value=os.environ.get("OPENAI_API_KEY", ""),
        help="환경변수로 설정해도 됩니다. 예: export OPENAI_API_KEY='...'",
    )

    model = st.selectbox(
        "텍스트 생성 모델",
        options=[
            "gpt-5.2",
            "gpt-5",
            "gpt-4.1",
            "gpt-4o-2024-08-06",
            "gpt-4o-mini",
            "gpt-4.1-mini",
        ],
        index=0,
        help="계정/티어에 따라 접근 가능한 모델이 다를 수 있어요. 안 되면 gpt-4o-2024-08-06 또는 gpt-4o-mini로 바꿔보세요.",
    )

    embedding_model = st.selectbox(
        "임베딩 모델(클러스터링)",
        options=["text-embedding-3-small", "text-embedding-3-large"],
        index=0,
    )

    st.divider()

    top_n = st.slider("요약할 Top N 콘텐츠", min_value=1, max_value=10, value=5)

    weight_visits = st.slider(
        "스코어 가중치: 방문수(views)",
        min_value=0.0,
        max_value=1.0,
        value=0.6,
        step=0.05,
    )
    weight_dwell = 1.0 - weight_visits
    st.write(f"스코어 가중치: 체류시간 = **{weight_dwell:.2f}**")

    st.divider()

    use_web_trends = st.checkbox("외부 트렌드(웹검색)도 참고", value=False)
    trend_query = ""
    if use_web_trends:
        trend_query = st.text_input(
            "외부 트렌드 검색 키워드",
            placeholder="예: 생성형AI 마케팅, B2B SaaS 그로스, 리테일 AI",
        )

    st.divider()
    st.subheader("새 콘텐츠 생성")
    persona = st.selectbox(
        "타겟 페르소나",
        options=[
            "스타트업 마케터(실무자)",
            "PM/PO",
            "개발자/데이터",
            "경영진/리더",
            "투자자/VC",
            "취준생/커리어 전환",
            "일반 독자(입문자)",
        ],
        index=0,
    )
    output_format = st.selectbox(
        "산출물 포맷",
        options=[
            "뉴스레터(5분 읽기)",
            "블로그 포스트(1500~2000자)",
            "LinkedIn 글(인사이트 + CTA)",
            "X(트위터) 스레드(10개 트윗)",
            "숏폼 영상 대본(60초)",
            "카루셀/슬라이드 스크립트(8장)",
        ],
        index=0,
    )

    brand_tone = st.text_area(
        "추가 컨텍스트/브랜드 톤(선택)",
        placeholder="예: 톤은 친근하지만 전문적으로. 문장 짧게. 마지막에 제품 CTA 넣기.",
        height=120,
    )


# ---------------------------
# Helpers
# ---------------------------
@st.cache_data(show_spinner=False, ttl=60 * 60)
def cached_fetch(url: str):
    return fetch_and_extract(url)


def ensure_ai() -> OpenAIService:
    return OpenAIService(api_key=api_key, model=model, embedding_model=embedding_model)


# ---------------------------
# Main UI
# ---------------------------
tab1, tab2, tab3 = st.tabs(["1) 데이터 업로드", "2) 요약/인사이트", "3) 새 콘텐츠 생성"])


with tab1:
    st.subheader("Analytics CSV 업로드")

    st.markdown(
        """
**CSV 최소 컬럼(예시)**  
- `url` : 페이지/콘텐츠 URL  
- `visits` : 조회수/방문수(pageviews/views/sessions 등)  
- `avg_dwell_sec` : 평균 체류 시간(초) — 또는 `mm:ss`, `hh:mm:ss`도 인식  

(선택) `title` 컬럼이 있으면 더 보기 좋게 표시됩니다.
"""
    )

    uploaded = st.file_uploader("CSV 파일", type=["csv"])
    if uploaded is not None:
        try:
            df = load_metrics_csv(uploaded)
            df_scored = compute_engagement_score(df, weight_visits=weight_visits, weight_dwell=weight_dwell)
            top_df = top_by_score(df_scored, top_n=top_n)

            st.session_state["df_scored"] = df_scored
            st.session_state["top_df"] = top_df

            st.success(f"업로드 완료! 총 {len(df_scored)}개 행을 읽었습니다.")
            st.write("상위 콘텐츠(스코어 기준):")
            st.dataframe(
                top_df[["title", "url", "visits", "avg_dwell_sec", "avg_dwell_min", "engagement_score"]],
                use_container_width=True,
            )

        except Exception as e:
            st.error(str(e))
    else:
        st.info("샘플 CSV가 필요하면 `sample_data/metrics_sample.csv`를 사용해보세요.")


with tab2:
    st.subheader("Top 콘텐츠 요약 & 인사이트")

    if "top_df" not in st.session_state:
        st.warning("먼저 1) 탭에서 CSV를 업로드하세요.")
    else:
        top_df = st.session_state["top_df"]

        run = st.button("Top 콘텐츠 가져오기 + 요약 생성", type="primary")
        if run:
            try:
                ai = ensure_ai()
            except Exception as e:
                st.error(str(e))
                st.stop()

            summaries: List[Dict[str, Any]] = []

            progress = st.progress(0, text="시작...")
            for i, row in enumerate(top_df.to_dict(orient="records"), start=1):
                url = row["url"]
                title_hint = row.get("title", "")
                metrics = {"visits": float(row.get("visits", 0)), "avg_dwell_sec": float(row.get("avg_dwell_sec", 0))}

                with st.spinner(f"[{i}/{len(top_df)}] 가져오는 중: {url}"):
                    try:
                        fetched_title, text = cached_fetch(url)
                        page_title = fetched_title or title_hint or url
                    except Exception as e:
                        st.warning(f"가져오기 실패: {url}\n- {e}\n→ 해당 URL은 건너뜁니다.")
                        progress.progress(i / len(top_df), text="진행 중...")
                        continue

                with st.spinner("AI 요약 생성 중..."):
                    try:
                        summary = ai.summarize(url=url, title=page_title, content=text, metrics=metrics)
                        summaries.append(summary)
                    except Exception as e:
                        st.warning(f"요약 실패: {url}\n- {e}\n→ 해당 URL은 건너뜁니다.")

                progress.progress(i / len(top_df), text="진행 중...")

            progress.empty()

            st.session_state["summaries"] = summaries

            if summaries:
                # clustering (optional)
                try:
                    vectors = ai.embed_texts([s.get("summary", "") for s in summaries])
                    clusters = cluster_summaries(vectors, summaries, max_clusters=3)
                    st.session_state["clusters"] = clusters
                except Exception as e:
                    st.warning(f"클러스터링 실패(무시 가능): {e}")

                st.success(f"완료! 요약 {len(summaries)}개 생성.")
            else:
                st.error("요약 결과가 없습니다. URL 접근 또는 모델/키 설정을 확인해주세요.")

        # Display results
        if "summaries" in st.session_state and st.session_state["summaries"]:
            summaries = st.session_state["summaries"]

            colA, colB = st.columns([1, 1])
            with colA:
                st.markdown("### 요약 리스트")
                for idx, s in enumerate(summaries, start=1):
                    with st.expander(f"{idx}. {s.get('title','(no title)')}", expanded=False):
                        st.write(f"**URL:** {s.get('url')}")
                        st.write(f"**One-liner:** {s.get('one_liner')}")
                        st.write("**Summary:**")
                        st.write(s.get("summary"))
                        st.write("**Key points:**")
                        st.write("\n".join([f"- {x}" for x in (s.get("key_points") or [])]))
                        st.write("**Tags:** " + ", ".join(s.get("tags") or []))
                        st.write("**Audience:** " + ", ".join(s.get("audience") or []))
                        st.write("**Angles:**")
                        st.write("\n".join([f"- {x}" for x in (s.get("recommended_angles") or [])]))
                        if s.get("risk_notes"):
                            st.info(s.get("risk_notes"))

            with colB:
                st.markdown("### 트렌드 클러스터(선택)")
                clusters = st.session_state.get("clusters", [])
                if clusters:
                    for c in clusters:
                        with st.expander(f"클러스터: {c['label']} (n={len(c['items'])})", expanded=False):
                            for it in c["items"]:
                                st.write(f"- {it.get('title')} ({it.get('url')})")
                else:
                    st.caption("클러스터를 만들 수 없거나(요약 1개), 임베딩 호출에 실패했을 수 있어요.")

        else:
            st.info("아직 요약이 없습니다. 버튼을 눌러 생성하세요.")


with tab3:
    st.subheader("타겟 맞춤 새 콘텐츠 생성")

    if "summaries" not in st.session_state or not st.session_state["summaries"]:
        st.warning("먼저 2) 탭에서 요약을 생성하세요.")
    else:
        summaries = st.session_state["summaries"]

        st.markdown(
            """
이 단계는 **요약 인사이트를 바탕으로 '완전히 새로운' 콘텐츠**를 생성합니다.  
(원문을 길게 복사하지 않도록 모델에게 강하게 지시합니다.)
"""
        )

        if st.button("새 콘텐츠 생성", type="primary"):
            try:
                ai = ensure_ai()
            except Exception as e:
                st.error(str(e))
                st.stop()

            external_trends = ""
            if use_web_trends and trend_query.strip():
                with st.spinner("외부 트렌드(웹검색) 가져오는 중..."):
                    try:
                        external_trends = ai.web_trends(trend_query.strip())
                    except Exception as e:
                        st.warning(f"외부 트렌드 실패(무시 가능): {e}")

            with st.spinner("새 콘텐츠 생성 중..."):
                try:
                    output_md = ai.generate_content(
                        summaries=summaries,
                        persona=persona,
                        output_format=output_format,
                        additional_context=brand_tone,
                        external_trends=external_trends,
                    )
                except Exception as e:
                    st.error(str(e))
                    st.stop()

            st.markdown("### 결과(복사/다운로드 가능)")
            st.markdown(output_md)

            st.download_button(
                label="Markdown 다운로드",
                data=output_md,
                file_name=f"staypick_{datetime.now().strftime('%Y%m%d_%H%M')}.md",
                mime="text/markdown",
            )

        with st.expander("요약 데이터(JSON) 보기", expanded=False):
            st.code(json.dumps(summaries, ensure_ascii=False, indent=2), language="json")
